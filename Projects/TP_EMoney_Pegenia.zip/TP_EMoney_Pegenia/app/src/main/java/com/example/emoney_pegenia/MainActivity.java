package com.example.emoney_pegenia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.registration.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public static String[][] users = {
            {"jaideu", "1234", "Jade"}, {"1234", "1235", "1237"}
    };
    public void newUsers(String uname, String password, String name) {
        String[][] user = new String[users.length + 1][3];
        for (int x = 0; x < users.length; x++) {
            user[x] = users[x];
        }
        user[users.length] = new String[]{
                uname, password, name
        };
        users = user;
    }

    public void Account(View view) {
        Intent Account = new Intent(this, Registration.class);
        startActivity(Account);
    }

    public void ValidateLogin(View view) {
        Intent intent = new Intent(this, homepage.class);
        EditText etUsername = (findViewById(R.id.Username));
        EditText etPassword = (findViewById(R.id.Password));
        String username = etUsername.getText().toString();
        String pssword = etPassword.getText().toString();
        boolean logged = false;
        if (!username.equals("") || !pssword.equals("")) {
            for (String[] user : users) {
                if (user[0].equals(username) && user[1].equals(pssword)) {
                    Toast.makeText(this, "Sucess Login", Toast.LENGTH_SHORT).show();
                    intent.putExtra(EXTRA_MESSAGE, user[2]);
                    startActivity(intent);
                    logged = true;
                    break;
                }
            }
        }
        if (!logged) {
            Toast.makeText(this, "Error Login", Toast.LENGTH_SHORT).show();
        }
    }
}