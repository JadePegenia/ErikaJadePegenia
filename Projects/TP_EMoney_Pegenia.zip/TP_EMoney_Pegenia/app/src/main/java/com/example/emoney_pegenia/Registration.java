package com.example.emoney_pegenia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }


    public void ValidateRegister(View view) {
        Intent intent = new Intent(this, MainActivity.class);

        MainActivity login = new MainActivity();
        EditText UserName = (findViewById(R.id.Uname));
        EditText Password = (findViewById(R.id.Pssword));
        EditText Name = (findViewById(R.id.Name));
        EditText cPassword = (findViewById(R.id.CPassword));

        String username = UserName.getText().toString();
        String password = Password.getText().toString();
        String name = Name.getText().toString();
        String cpssword = cPassword.getText().toString();


        if (password.equals(cpssword)) {
            login.newUsers(username, password, name);
            Toast.makeText(this, "Account Successfully Created", Toast.LENGTH_SHORT).show();

            try {
                Thread.sleep(2000);
                startActivity(intent);
            } catch (Exception e) {

            }

        }else{
            Toast.makeText(this, "Password Mismatch", Toast.LENGTH_SHORT).show();
        }
    }
}
