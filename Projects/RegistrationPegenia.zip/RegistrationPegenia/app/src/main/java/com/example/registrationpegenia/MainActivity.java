package com.example.registrationpegenia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.registration.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void First_Name(){
        EditText firstname = findViewById(R.id.FName);
        String fName = firstname.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, fName);
        startActivity(intent);


    }
    public void Last_Name(){
        EditText lastname = findViewById(R.id.LName);
        String lName = lastname.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, lName);
        startActivity(intent);

    }
    public void Email(){
        EditText email = findViewById(R.id.Email);
        String Email = email.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, Email);
        startActivity(intent);
    }
    public void Password(){
        EditText password = findViewById(R.id.Password);
        String pw = password.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, pw);
        startActivity(intent);
    }
    public void Confirm(){
        EditText confirm = findViewById(R.id.Confirm);
        String Confirm = confirm.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, Confirm);
        startActivity(intent);
    }
    public void Sign_Up(){
        Button signup = findViewById(R.id.Signup);
        Intent intent = new Intent(this,second.class);
        startActivity(intent);
    }
    public void second(View fName){
        EditText firstname = findViewById(R.id.FName);
        String firstName = firstname.getText().toString();
        Intent intent = new Intent(this,second.class);
        intent.putExtra(EXTRA_MESSAGE, firstName);
        startActivity(intent);
    }

}