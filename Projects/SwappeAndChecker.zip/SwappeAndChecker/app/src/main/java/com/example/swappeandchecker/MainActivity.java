package com.example.swappeandchecker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Swap(View view){
        EditText Textview = (findViewById(R.id.editTextText));
        EditText Textviews = (findViewById(R.id.editTextText2));

        String textview =  Textview.getText().toString();
        String textviews =  Textviews.getText().toString();
        Textview.setText(textviews);
        Textviews.setText(textview);


    }

   public void CheckButton(View view){
       Intent intent = new Intent(this, MainActivity2.class);
       EditText Text = (findViewById(R.id.editTextText));
       EditText Text2 = (findViewById(R.id.editTextText2));

       String text1 = Text.getText().toString();
       String text2 = Text2.getText().toString();


       String message;
       if (text1.equals(text2)){
          message = "SAME";
       }else{
           message ="NOT THE SAME";

       }
       intent.putExtra("MESSAGE", message);
       startActivity(intent);
   }
}